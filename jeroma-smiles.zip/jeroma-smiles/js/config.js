/* ==========================================================
   Jeroma Smiles — configuration
   Fill these two values from Supabase → Project Settings → API.
   Use ONLY the "anon / public" key. NEVER put the service_role
   key anywhere in this website. The anon key is safe to be public
   because Row Level Security (supabase/schema.sql) protects the data.
   ========================================================== */
window.JEROMA_CONFIG = {
  SUPABASE_URL: "https://YOUR-PROJECT-REF.supabase.co",
  SUPABASE_ANON_KEY: "YOUR-SUPABASE-ANON-PUBLIC-KEY"
};
