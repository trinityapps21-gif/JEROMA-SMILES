/* Jeroma Smiles — authentication (Supabase Auth).
   - No credentials live in this file or in the repository.
   - The session is kept in sessionStorage (cleared when the tab closes),
     never in localStorage.
   - Real security is enforced by Row Level Security in the database;
     the redirects here are only a convenience. */
(function () {
  "use strict";
  var cfg = window.JEROMA_CONFIG || {};
  var configured = cfg.SUPABASE_URL && cfg.SUPABASE_URL.indexOf("YOUR-PROJECT") === -1 && window.supabase;

  var client = configured
    ? window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, {
        auth: { storage: window.sessionStorage, persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
      })
    : null;

  // Returns {user, profile} when signed in AND listed as a principal, otherwise null.
  function getPrincipal() {
    if (!client) return Promise.resolve(null);
    return client.auth.getSession().then(function (r) {
      var session = r.data && r.data.session;
      if (!session) return null;
      return client.from("admin_profiles").select("id,name,email,role,created_at").eq("id", session.user.id).maybeSingle()
        .then(function (p) {
          if (p.error || !p.data || p.data.role !== "principal") return null;
          return { user: session.user, profile: p.data };
        });
    });
  }

  function signOut() {
    var done = function () { window.location.replace("principal-login.html"); };
    return client ? client.auth.signOut().then(done, done) : done();
  }

  window.JS_AUTH = { client: client, configured: !!configured, getPrincipal: getPrincipal, signOut: signOut };

  // ---------- Login page ----------
  var form = document.getElementById("loginForm");
  if (!form) return;
  var msg = document.getElementById("loginMsg");
  var btn = form.querySelector("button[type=submit]");
  var resetForm = document.getElementById("resetForm");

  function say(kind, text) { msg.className = "form-msg show " + kind; msg.textContent = text; }

  if (!configured) {
    say("bad", "Sign-in is not connected yet. Add the Supabase details to js/config.js (see README).");
    btn.disabled = true;
    return;
  }

  // Already signed in as principal → go to dashboard
  getPrincipal().then(function (pr) { if (pr) window.location.replace("dashboard.html"); });

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var email = form.elements.email.value.trim();
    var password = form.elements.password.value;
    if (!email || !password) { say("bad", "Enter your email and password."); return; }
    btn.disabled = true; btn.textContent = "Signing in…";
    client.auth.signInWithPassword({ email: email, password: password }).then(function (r) {
      if (r.error) throw new Error("bad");
      return getPrincipal();
    }).then(function (pr) {
      if (!pr) { return client.auth.signOut().then(function () { throw new Error("denied"); }); }
      window.location.replace("dashboard.html");
    }).catch(function (err) {
      say("bad", err.message === "denied"
        ? "This account is not authorised to use the principal dashboard."
        : "Sign-in failed. Check your email and password.");
      btn.disabled = false; btn.textContent = "Sign In";
    });
  });

  // Forgot password → email link
  var forgot = document.getElementById("forgotLink");
  forgot.addEventListener("click", function (e) {
    e.preventDefault();
    var email = form.elements.email.value.trim();
    if (!email) { say("bad", "Type your email address above first, then press Forgot Password."); form.elements.email.focus(); return; }
    var redirect = window.location.origin + window.location.pathname;
    client.auth.resetPasswordForEmail(email, { redirectTo: redirect }).then(function () {
      say("ok", "If that email belongs to an administrator, a password reset link has been sent.");
    });
  });

  // Returning from the reset email → let the user choose a new password
  client.auth.onAuthStateChange(function (event) {
    if (event === "PASSWORD_RECOVERY" && resetForm) {
      form.style.display = "none"; resetForm.style.display = "grid";
      say("ok", "Choose a new password.");
    }
  });
  if (resetForm) {
    resetForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var p1 = resetForm.elements.newpass.value, p2 = resetForm.elements.newpass2.value;
      if (p1.length < 8) { say("bad", "Password must be at least 8 characters."); return; }
      if (p1 !== p2) { say("bad", "The two passwords do not match."); return; }
      client.auth.updateUser({ password: p1 }).then(function (r) {
        if (r.error) { say("bad", "Could not update the password. The link may have expired."); return; }
        return client.auth.signOut().then(function () {
          resetForm.style.display = "none"; form.style.display = "grid";
          say("ok", "Password updated. Please sign in with your new password.");
        });
      });
    });
  }
})();
