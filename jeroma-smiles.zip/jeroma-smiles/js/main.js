/* Jeroma Smiles — shared site behaviour (nav, menu, reveal animations) */
(function () {
  "use strict";
  var header = document.querySelector(".site-header");
  var panel = document.getElementById("menuPanel");
  var openBtn = document.getElementById("menuOpen");
  var closeBtn = document.getElementById("menuClose");

  function onScroll() {
    if (header) header.classList.toggle("scrolled", window.scrollY > 10);
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  function setMenu(open) {
    if (!panel) return;
    panel.classList.toggle("open", open);
    openBtn && openBtn.setAttribute("aria-expanded", String(open));
    document.body.style.overflow = open ? "hidden" : "";
    if (open && closeBtn) closeBtn.focus();
    if (!open && openBtn) openBtn.focus();
  }
  openBtn && openBtn.addEventListener("click", function () { setMenu(true); });
  closeBtn && closeBtn.addEventListener("click", function () { setMenu(false); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && panel && panel.classList.contains("open")) setMenu(false);
  });
  if (panel) {
    panel.querySelectorAll("a").forEach(function (a) {
      a.addEventListener("click", function () { document.body.style.overflow = ""; });
    });
  }

  // Scroll reveal + timeline line animation (respects reduced motion via CSS)
  var targets = document.querySelectorAll(".reveal, .timeline");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.15 });
    targets.forEach(function (t) { io.observe(t); });
  } else {
    targets.forEach(function (t) { t.classList.add("in"); });
  }
})();
