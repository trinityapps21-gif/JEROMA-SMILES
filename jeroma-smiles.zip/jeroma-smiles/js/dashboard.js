/* Jeroma Smiles — Principal Dashboard.
   All data comes from Supabase and is protected by Row Level Security.
   Everything rendered from the database is HTML-escaped (esc) because
   applications/enquiries are written by the public. */
(function () {
  "use strict";
  var A = window.JS_AUTH;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  var TZ = "Africa/Kampala";
  function fmt(d, withTime) {
    if (!d) return "—";
    var o = { timeZone: TZ, day: "2-digit", month: "short", year: "numeric" };
    if (withTime) { o.hour = "2-digit"; o.minute = "2-digit"; }
    return new Date(d).toLocaleString("en-GB", o);
  }
  function refId(a) { return "JS-" + String(a.ref_no).padStart(4, "0"); }
  function pill(s) { return '<span class="pill pill-' + esc(String(s).toLowerCase().replace(/\s+/g, "-")) + '">' + esc(s) + "</span>"; }
  function toast(t, bad) {
    var el = $("#toast"); el.textContent = t; el.className = "toast show" + (bad ? " bad" : "");
    clearTimeout(toast._t); toast._t = setTimeout(function () { el.className = "toast"; }, 3200);
  }

  var state = { apps: [], enqs: [], me: null, user: null };
  var client = A.client;

  // ---------- Guard ----------
  if (!A.configured) { window.location.replace("principal-login.html"); return; }
  A.getPrincipal().then(function (pr) {
    if (!pr) { window.location.replace("principal-login.html"); return; }
    state.me = pr.profile; state.user = pr.user;
    $("#who").textContent = pr.profile.name || pr.profile.email;
    document.documentElement.classList.remove("auth-pending");
    load();
  });
  client && client.auth.onAuthStateChange(function (ev) { if (ev === "SIGNED_OUT") window.location.replace("principal-login.html"); });

  function load() {
    return Promise.all([
      client.from("applications").select("*").order("created_at", { ascending: false }).range(0, 4999),
      client.from("enquiries").select("*").order("created_at", { ascending: false }).range(0, 4999)
    ]).then(function (r) {
      if (r[0].error || r[1].error) { toast("Could not load data. Check your connection and permissions.", true); return; }
      state.apps = r[0].data; state.enqs = r[1].data;
      renderAll();
    });
  }

  function count(arr, fn) { return arr.filter(fn).length; }
  function renderAll() { renderOverview(); renderAdmissions(); renderEnquiries(); renderAnalytics(); renderProfile(); badges(); }

  function badges() {
    var n = count(state.apps, function (a) { return a.status === "New"; });
    var u = count(state.enqs, function (e) { return e.status === "Unread"; });
    $("#badgeApps").textContent = n || ""; $("#badgeApps").hidden = !n;
    $("#badgeEnq").textContent = u || ""; $("#badgeEnq").hidden = !u;
  }

  // ---------- Overview ----------
  function renderOverview() {
    var a = state.apps;
    var cards = [
      ["New Applications", count(a, function (x) { return x.status === "New"; }), "accent-y"],
      ["Pending (Under Review)", count(a, function (x) { return x.status === "Under Review"; }), ""],
      ["Accepted", count(a, function (x) { return x.status === "Accepted"; }), "accent-g"],
      ["Declined", count(a, function (x) { return x.status === "Declined"; }), "accent-r"],
      ["Total Enquiries", state.enqs.length, ""],
      ["Total Applications", a.length, ""]
    ];
    $("#cards").innerHTML = cards.map(function (c) {
      return '<div class="stat ' + c[2] + '"><span>' + esc(c[0]) + "</span><b>" + c[1] + "</b></div>";
    }).join("");
    var rows = a.slice(0, 8).map(function (x) { return appRow(x); }).join("");
    $("#recentBody").innerHTML = rows || '<tr><td colspan="8" class="empty">No applications yet.</td></tr>';
  }

  function appRow(x) {
    return "<tr>" +
      '<td data-label="Date">' + esc(fmt(x.created_at)) + "</td>" +
      '<td data-label="Application ID">' + esc(refId(x)) + "</td>" +
      '<td data-label="Parent">' + esc(x.parent_name) + "</td>" +
      '<td data-label="Child">' + esc(x.child_name) + "</td>" +
      '<td data-label="Programme">' + esc(x.programme) + "</td>" +
      '<td data-label="Day/Boarding">' + esc(x.school_type) + "</td>" +
      '<td data-label="Status">' + pill(x.status) + "</td>" +
      '<td data-label=""><button class="btn-sm" data-view-app="' + esc(x.id) + '">View</button></td></tr>';
  }

  // ---------- Admissions list ----------
  function renderAdmissions() {
    var q = $("#appSearch").value.trim().toLowerCase();
    var s = $("#fStatus").value, t = $("#fType").value, p = $("#fProg").value;
    var list = state.apps.filter(function (x) {
      if (s && x.status !== s) return false;
      if (t && x.school_type !== t) return false;
      if (p && x.programme !== p) return false;
      if (!q) return true;
      return [x.parent_name, x.child_name, x.parent_phone, refId(x), String(x.ref_no)].join(" ").toLowerCase().indexOf(q) > -1;
    });
    $("#appCount").textContent = list.length + " of " + state.apps.length + " applications";
    $("#appBody").innerHTML = list.map(appRow).join("") || '<tr><td colspan="8" class="empty">No applications match.</td></tr>';
  }
  ["appSearch", "fStatus", "fType", "fProg"].forEach(function (id) {
    $("#" + id).addEventListener(id === "appSearch" ? "input" : "change", renderAdmissions);
  });
  $("#clearFilters").addEventListener("click", function () {
    $("#appSearch").value = ""; $("#fStatus").value = ""; $("#fType").value = ""; $("#fProg").value = ""; renderAdmissions();
  });

  // ---------- Application detail ----------
  var currentId = null, lastFocus = null;
  document.addEventListener("click", function (e) {
    var b = e.target.closest("[data-view-app]");
    if (b) openDetail(b.getAttribute("data-view-app"), b);
  });
  function openDetail(id, trigger) {
    var x = state.apps.filter(function (a) { return a.id === id; })[0];
    if (!x) return;
    currentId = id; lastFocus = trigger || document.activeElement;
    $("#detailBody").innerHTML =
      '<div class="d-grid">' +
      '<section><h4>Parent Information</h4><dl><dt>Name</dt><dd>' + esc(x.parent_name) + '</dd><dt>Phone</dt><dd><a href="tel:' + esc(x.parent_phone) + '">' + esc(x.parent_phone) + '</a></dd><dt>Email</dt><dd><a href="mailto:' + esc(x.parent_email) + '">' + esc(x.parent_email) + "</a></dd></dl></section>" +
      '<section><h4>Child Information</h4><dl><dt>Name</dt><dd>' + esc(x.child_name) + "</dd><dt>Age</dt><dd>" + esc(x.child_age) + "</dd><dt>Programme</dt><dd>" + esc(x.programme) + "</dd><dt>Day / Boarding</dt><dd>" + esc(x.school_type) + "</dd></dl></section>" +
      '<section class="wide"><h4>Message</h4><p class="msg">' + (x.message ? esc(x.message) : "<em>No message provided.</em>") + "</p></section>" +
      '<section class="wide"><h4>Application</h4><dl><dt>ID</dt><dd>' + esc(refId(x)) + "</dd><dt>Date</dt><dd>" + esc(fmt(x.created_at, true)) + "</dd><dt>Status</dt><dd>" + pill(x.status) + "</dd></dl></section></div>";
    $("#detailTitle").textContent = refId(x) + " — " + x.child_name;
    $("#detail").classList.add("open"); document.body.style.overflow = "hidden";
    $("#detailClose").focus();
  }
  function closeDetail() { $("#detail").classList.remove("open"); document.body.style.overflow = ""; currentId = null; lastFocus && lastFocus.focus && lastFocus.focus(); }
  $("#detailClose").addEventListener("click", closeDetail);
  $("#detail").addEventListener("click", function (e) { if (e.target.id === "detail") closeDetail(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && $("#detail").classList.contains("open")) closeDetail(); });

  $$("[data-set-status]").forEach(function (b) {
    b.addEventListener("click", function () {
      var s = b.getAttribute("data-set-status");
      var x = state.apps.filter(function (a) { return a.id === currentId; })[0];
      if (!x || x.status === s) return;
      if ((s === "Accepted" || s === "Declined") &&
        !window.confirm("Mark " + refId(x) + " (" + x.child_name + ") as " + s.toUpperCase() + "?\n\nThis updates the application record.")) return;
      b.disabled = true;
      client.from("applications").update({ status: s }).eq("id", x.id).select().single().then(function (r) {
        b.disabled = false;
        if (r.error) { toast("Could not update the status.", true); return; }
        x.status = r.data.status; renderAll(); openDetail(x.id, lastFocus);
        toast("Status updated to " + s + ".");
      });
    });
  });

  // ---------- Enquiries ----------
  function renderEnquiries() {
    var f = $("#enqFilter").value;
    var list = state.enqs.filter(function (e) { return !f || e.status === f; });
    $("#enqList").innerHTML = list.map(function (e) {
      return '<article class="enq ' + (e.status === "Unread" ? "unread" : "") + '">' +
        '<header><div><b>' + esc(e.subject) + '</b><span class="muted">' + esc(e.name) + " · " + esc(fmt(e.created_at, true)) + "</span></div>" + pill(e.status) + "</header>" +
        '<p class="msg">' + esc(e.message) + "</p>" +
        '<footer><span><a href="mailto:' + esc(e.email) + '">' + esc(e.email) + "</a>" + (e.phone ? ' · <a href="tel:' + esc(e.phone) + '">' + esc(e.phone) + "</a>" : "") + "</span>" +
        '<span class="seg" role="group" aria-label="Set status">' +
        ["Unread", "Read", "Resolved"].map(function (s) {
          return '<button class="btn-sm' + (e.status === s ? " on" : "") + '" data-enq="' + esc(e.id) + '" data-st="' + s + '">' + s + "</button>";
        }).join("") + "</span></footer></article>";
    }).join("") || '<p class="empty-block">No enquiries here.</p>';
  }
  $("#enqFilter").addEventListener("change", renderEnquiries);
  $("#enqList").addEventListener("click", function (e) {
    var b = e.target.closest("[data-enq]"); if (!b) return;
    var id = b.getAttribute("data-enq"), s = b.getAttribute("data-st");
    client.from("enquiries").update({ status: s }).eq("id", id).select().single().then(function (r) {
      if (r.error) { toast("Could not update the enquiry.", true); return; }
      state.enqs.forEach(function (x) { if (x.id === id) x.status = r.data.status; });
      renderEnquiries(); renderOverview(); badges();
    });
  });

  // ---------- Analytics ----------
  function bars(rows, total) {
    var max = Math.max.apply(null, rows.map(function (r) { return r[1]; }).concat([1]));
    return rows.map(function (r) {
      return '<div class="bar-row"><span class="bl">' + esc(r[0]) + '</span><span class="bt"><i style="width:' + (r[1] / max * 100) + '%;background:' + (r[2] || "var(--dark)") + '"></i></span><b>' + r[1] + (total ? ' <small>' + Math.round(r[1] / total * 100) + "%</small>" : "") + "</b></div>";
    }).join("");
  }
  function renderAnalytics() {
    var a = state.apps, n = a.length, now = new Date();
    var thisMonth = count(a, function (x) { var d = new Date(x.created_at); return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth(); });
    var pending = count(a, function (x) { return x.status === "New" || x.status === "Under Review"; });
    var tiles = [["Total applications", n], ["This month", thisMonth], ["Accepted", count(a, function (x) { return x.status === "Accepted"; })],
      ["Declined", count(a, function (x) { return x.status === "Declined"; })], ["Pending (awaiting decision)", pending]];
    // last 6 months
    var months = [];
    for (var i = 5; i >= 0; i--) {
      var d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push({ y: d.getFullYear(), m: d.getMonth(), label: d.toLocaleString("en-GB", { month: "short" }) });
    }
    var mrows = months.map(function (mo) {
      return [mo.label, count(a, function (x) { var d = new Date(x.created_at); return d.getFullYear() === mo.y && d.getMonth() === mo.m; }), "var(--secondary)"];
    });
    $("#analytics").innerHTML =
      '<div class="stats">' + tiles.map(function (t) { return '<div class="stat"><span>' + esc(t[0]) + "</span><b>" + t[1] + "</b></div>"; }).join("") + "</div>" +
      '<div class="a-grid">' +
      '<div class="panel"><h3>Status</h3>' + bars([["New", count(a, function (x) { return x.status === "New"; }), "var(--primary)"], ["Under Review", count(a, function (x) { return x.status === "Under Review"; }), "#8a8576"], ["Accepted", count(a, function (x) { return x.status === "Accepted"; }), "var(--accent)"], ["Declined", count(a, function (x) { return x.status === "Declined"; }), "var(--secondary)"]], n) + "</div>" +
      '<div class="panel"><h3>Day vs Boarding</h3>' + bars([["Day", count(a, function (x) { return x.school_type === "Day"; }), "var(--primary)"], ["Boarding", count(a, function (x) { return x.school_type === "Boarding"; }), "var(--dark)"]], n) + "</div>" +
      '<div class="panel"><h3>Programme</h3>' + bars(["Day Care", "Nursery", "UNEB Primary", "ACE", "Other"].map(function (p) { return [p, count(a, function (x) { return x.programme === p; }), "var(--dark)"]; }), n) + "</div>" +
      '<div class="panel"><h3>Applications — last 6 months</h3>' + bars(mrows, 0) + "</div></div>";
  }

  // ---------- Profile ----------
  function renderProfile() {
    var m = state.me, u = state.user;
    $("#profileInfo").innerHTML = "<dl><dt>Name</dt><dd>" + esc(m.name || "—") + "</dd><dt>Email</dt><dd>" + esc(m.email || u.email) + "</dd><dt>Role</dt><dd>" + esc(m.role) + "</dd><dt>Last login</dt><dd>" + esc(fmt(u.last_sign_in_at, true)) + "</dd></dl>";
  }
  $("#pwForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var f = e.target, p1 = f.elements.p1.value, p2 = f.elements.p2.value, m = $("#pwMsg");
    m.className = "form-msg show bad";
    if (p1.length < 8) { m.textContent = "Password must be at least 8 characters."; return; }
    if (p1 !== p2) { m.textContent = "The two passwords do not match."; return; }
    client.auth.updateUser({ password: p1 }).then(function (r) {
      if (r.error) { m.textContent = "Could not change the password. Please sign in again and retry."; return; }
      f.reset(); m.className = "form-msg show ok"; m.textContent = "Password changed successfully.";
    });
  });

  // ---------- Navigation ----------
  function go(view) {
    var ok = ["overview", "admissions", "enquiries", "analytics", "profile"];
    if (ok.indexOf(view) < 0) view = "overview";
    $$(".view").forEach(function (v) { v.hidden = v.id !== "view-" + view; });
    $$(".side a[data-view]").forEach(function (a) {
      var on = a.getAttribute("data-view") === view; a.classList.toggle("on", on); on ? a.setAttribute("aria-current", "page") : a.removeAttribute("aria-current");
    });
    $("#sidebar").classList.remove("open");
    window.scrollTo(0, 0);
  }
  window.addEventListener("hashchange", function () { go(location.hash.slice(1)); });
  go(location.hash.slice(1));
  $("#sideToggle").addEventListener("click", function () { $("#sidebar").classList.toggle("open"); });
  $("#logout").addEventListener("click", function (e) { e.preventDefault(); A.signOut(); });
  $("#refresh").addEventListener("click", function () { load().then(function () { toast("Data refreshed."); }); });
})();
