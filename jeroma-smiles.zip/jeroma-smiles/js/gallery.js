/* Jeroma Smiles — gallery: category filter + accessible lightbox.
   Categories are generated from the images that exist, so a category
   with no photos (e.g. Swimming) is never shown. To add a photo, drop
   it in /images and add one line to PHOTOS below. */
(function () {
  "use strict";
  var PHOTOS = [
    { src: "images/craft.jpg", w: 443, h: 590, cats: ["Learning"], alt: "A learner in a yellow school uniform holding up a card decorated with red button shapes", cap: "Creative learning with a hands-on craft" },
    { src: "images/friends.jpg", w: 720, h: 540, cats: ["Activities", "School Life"], alt: "A group of smiling children in white tops making playful hand gestures", cap: "Playtime with friends" },
    { src: "images/sand-play.jpg", w: 811, h: 540, cats: ["Activities", "School Life"], alt: "Young children playing with colourful toys in a sand area while a teacher helps", cap: "Outdoor sand play" },
    { src: "images/cake.jpg", w: 810, h: 540, cats: ["Baking"], alt: "A white two-tier celebration cake decorated with red lettering", cap: "A decorated celebration cake" },
    { src: "images/smiling-girl.jpg", w: 590, h: 393, cats: ["School Life"], alt: "A smiling child in a yellow school shirt outdoors", cap: "A smile from Jeroma Smiles" },
    { src: "images/meals.jpg", w: 526, h: 701, cats: ["School Life"], alt: "Bowls of rice with fried chicken laid out on a table", cap: "Food laid out on the table" }
  ];
  var ORDER = ["Learning", "Swimming", "Baking", "School Life", "Activities"];

  var grid = document.getElementById("galleryGrid");
  var bar = document.getElementById("galleryFilters");
  if (!grid || !bar) return;

  var current = "All";
  var visible = [];

  function cats() {
    var present = {};
    PHOTOS.forEach(function (p) { p.cats.forEach(function (c) { present[c] = true; }); });
    return ["All"].concat(ORDER.filter(function (c) { return present[c]; }));
  }

  function render() {
    visible = PHOTOS.filter(function (p) { return current === "All" || p.cats.indexOf(current) > -1; });
    grid.innerHTML = "";
    visible.forEach(function (p, i) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "g-item";
      b.setAttribute("aria-label", "Open photo: " + p.cap);
      var fig = document.createElement("figure");
      var img = document.createElement("img");
      img.src = p.src; img.alt = p.alt; img.width = p.w; img.height = p.h; img.loading = "lazy";
      var cap = document.createElement("figcaption");
      cap.textContent = p.cap;
      fig.appendChild(img); fig.appendChild(cap); b.appendChild(fig);
      b.addEventListener("click", function () { openLb(i); });
      grid.appendChild(b);
    });
  }

  cats().forEach(function (c) {
    var b = document.createElement("button");
    b.type = "button"; b.className = "filter"; b.textContent = c;
    b.setAttribute("aria-pressed", c === "All" ? "true" : "false");
    b.addEventListener("click", function () {
      current = c;
      bar.querySelectorAll(".filter").forEach(function (x) { x.setAttribute("aria-pressed", String(x === b)); });
      render();
    });
    bar.appendChild(b);
  });
  render();

  // Lightbox
  var lb = document.getElementById("lightbox");
  var lbImg = document.getElementById("lbImg");
  var lbCap = document.getElementById("lbCap");
  var idx = 0, lastFocus = null;

  function show() {
    var p = visible[idx];
    lbImg.src = p.src; lbImg.alt = p.alt; lbCap.textContent = p.cap + "  (" + (idx + 1) + " / " + visible.length + ")";
  }
  function openLb(i) { idx = i; lastFocus = document.activeElement; show(); lb.classList.add("open"); document.body.style.overflow = "hidden"; document.getElementById("lbClose").focus(); }
  function closeLb() { lb.classList.remove("open"); document.body.style.overflow = ""; lastFocus && lastFocus.focus(); }
  function move(d) { idx = (idx + d + visible.length) % visible.length; show(); }

  document.getElementById("lbClose").addEventListener("click", closeLb);
  document.getElementById("lbPrev").addEventListener("click", function () { move(-1); });
  document.getElementById("lbNext").addEventListener("click", function () { move(1); });
  lb.addEventListener("click", function (e) { if (e.target === lb) closeLb(); });
  document.addEventListener("keydown", function (e) {
    if (!lb.classList.contains("open")) return;
    if (e.key === "Escape") closeLb();
    else if (e.key === "ArrowLeft") move(-1);
    else if (e.key === "ArrowRight") move(1);
  });
  // Touch swipe
  var sx = null;
  lb.addEventListener("touchstart", function (e) { sx = e.touches[0].clientX; }, { passive: true });
  lb.addEventListener("touchend", function (e) {
    if (sx === null) return;
    var dx = e.changedTouches[0].clientX - sx;
    if (Math.abs(dx) > 50) move(dx > 0 ? -1 : 1);
    sx = null;
  });
})();
