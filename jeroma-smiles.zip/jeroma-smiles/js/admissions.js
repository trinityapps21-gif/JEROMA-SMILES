/* Jeroma Smiles — public forms (admissions + contact enquiries).
   Inserts a row into Supabase through its REST API using ONLY the public
   anon key. Row Level Security allows anonymous INSERT only (never read). */
(function () {
  "use strict";
  var cfg = window.JEROMA_CONFIG || {};
  var forms = document.querySelectorAll("form[data-table]");
  if (!forms.length) return;

  var RULES = {
    parent_name: { min: 2, max: 120, label: "Please enter your full name." },
    child_name: { min: 2, max: 120, label: "Please enter your child's name." },
    name: { min: 2, max: 120, label: "Please enter your name." },
    subject: { min: 2, max: 150, label: "Please enter a subject." },
    message: { min: 0, max: 2000, label: "Message is too long (max 2000 characters)." }
  };
  var PHONE = /^[+0-9][0-9\s\-()]{6,19}$/;
  var EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function setErr(field, msg) {
    var wrap = field.closest(".field");
    if (!wrap) return;
    wrap.classList.toggle("invalid", !!msg);
    var e = wrap.querySelector(".err");
    if (e) e.textContent = msg || "";
    field.setAttribute("aria-invalid", msg ? "true" : "false");
  }

  function validateField(f) {
    var v = (f.value || "").trim();
    var n = f.name;
    if (f.required && !v) { setErr(f, "This field is required."); return false; }
    if (!v && !f.required) { setErr(f, ""); return true; }
    if (RULES[n]) {
      if (v.length < RULES[n].min || v.length > RULES[n].max) { setErr(f, RULES[n].label); return false; }
    }
    if (n === "parent_phone" || n === "phone") { if (!PHONE.test(v)) { setErr(f, "Enter a valid phone number, e.g. +256 700 000000."); return false; } }
    if (n === "parent_email" || n === "email") { if (!EMAIL.test(v)) { setErr(f, "Enter a valid email address."); return false; } }
    if (n === "child_age") {
      var a = Number(v);
      if (!Number.isInteger(a) || a < 0 || a > 18) { setErr(f, "Enter an age between 0 and 18."); return false; }
    }
    setErr(f, ""); return true;
  }

  forms.forEach(function (form) {
    var table = form.getAttribute("data-table");
    var msg = form.querySelector(".form-msg");
    var btn = form.querySelector("button[type=submit]");

    function show(kind, text) {
      msg.className = "form-msg show " + kind;
      msg.textContent = text;
      msg.focus && msg.focus();
    }

    form.querySelectorAll("input,select,textarea").forEach(function (f) {
      f.addEventListener("blur", function () { if (f.name && f.name !== "website") validateField(f); });
    });

    form.addEventListener("submit", function (ev) {
      ev.preventDefault();
      msg.className = "form-msg";
      // Honeypot: bots fill the hidden field, humans never see it
      if (form.elements["website"] && form.elements["website"].value) return;

      var ok = true, first = null;
      form.querySelectorAll("input,select,textarea").forEach(function (f) {
        if (!f.name || f.name === "website") return;
        if (!validateField(f)) { ok = false; first = first || f; }
      });
      if (!ok) { first.focus(); show("bad", "Please correct the highlighted fields and try again."); return; }

      if (!cfg.SUPABASE_URL || cfg.SUPABASE_URL.indexOf("YOUR-PROJECT") > -1) {
        show("bad", "The form is not connected yet. The website administrator needs to add the Supabase details in js/config.js.");
        return;
      }

      var payload = {};
      form.querySelectorAll("input,select,textarea").forEach(function (f) {
        if (!f.name || f.name === "website") return;
        var v = f.value.trim();
        payload[f.name] = f.name === "child_age" ? parseInt(v, 10) : v;
      });

      btn.disabled = true;
      var label = btn.textContent;
      btn.textContent = "Sending…";

      fetch(cfg.SUPABASE_URL + "/rest/v1/" + table, {
        method: "POST",
        headers: {
          "apikey": cfg.SUPABASE_ANON_KEY,
          "Authorization": "Bearer " + cfg.SUPABASE_ANON_KEY,
          "Content-Type": "application/json",
          "Prefer": "return=minimal"
        },
        body: JSON.stringify(payload)
      }).then(function (res) {
        if (!res.ok) throw new Error("HTTP " + res.status);
        form.reset();
        form.querySelectorAll(".field").forEach(function (w) { w.classList.remove("invalid"); });
        show("ok", table === "applications"
          ? "Thank you. Your application has been received and the school will be in touch."
          : "Thank you. Your message has been sent and the school will reply soon.");
      }).catch(function () {
        show("bad", "Sorry, we could not send this just now. Please check your connection and try again.");
      }).then(function () {
        btn.disabled = false; btn.textContent = label;
      });
    });
  });
})();
