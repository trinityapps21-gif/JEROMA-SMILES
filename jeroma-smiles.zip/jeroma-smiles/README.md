# Jeroma Smiles Schools — Website & Principal Dashboard

Public website + admissions system + principal dashboard for **Jeroma Smiles Day Care and Nursery**
(Busambaga, Canaan Sites, Katabi, Entebbe, Uganda).
Developed by **Emtrixz Technology Company**.

- **Frontend:** plain HTML / CSS / JavaScript — hosted free on **GitHub Pages** (no server).
- **Backend:** **Supabase** (Auth, Postgres database, Row Level Security, Edge Function for email).

```
jeroma-smiles/
├── index.html … contact.html      public pages
├── principal-login.html           principal sign-in (Supabase Auth)
├── dashboard.html                 principal dashboard
├── css/  style.css, dashboard.css
├── js/   config.js  main.js  gallery.js  admissions.js  auth.js  dashboard.js
├── images/  logo.png + photos
├── favicon/favicon.png
└── supabase/
    ├── schema.sql                          tables + indexes + RLS policies
    └── functions/notify-application/       email notification (Resend)
```

---

## 0. Before you start — things to replace

| Item | Where | Status |
|---|---|---|
| **Official logo** | save as `images/logo.png` (and a small square version as `favicon/favicon.png`) | ⚠️ A **temporary placeholder** is included. Replace it. |
| **Brand colours** | `:root` at the top of `css/style.css` | Currently taken from the uniform photos (yellow `#F5B315`, red `#C81E2C`). Update `--primary`, `--secondary`, `--accent` to match the logo. |
| **Founder photo** | save as `images/founder.jpg` | Optional; a note shows until added. |
| **Swimming photos** | add to `images/`, then add a line in `js/gallery.js` (`PHOTOS`) | Swimming appears in the gallery only once a photo exists. |
| **Phone, email, hours, fees, admission requirements, boarding details** | search the HTML for `placeholder` (yellow boxes) | Not provided → left as marked placeholders. |
| **Google Maps URL** | `contact.html` ("Get Directions" button) | Currently a Google Maps *search* link; replace with the official link. |
| **Domain** | search `REPLACE-WITH-YOUR-DOMAIN.example` in all `.html` files | Used for canonical/Open Graph URLs. |
| **Supabase keys** | `js/config.js` | See step 4. |

> Photos supplied were renamed: `hero.jpg`, `friends.jpg`, `smiling-girl.jpg`, `craft.jpg`, `sand-play.jpg`, `meals.jpg`, `cake.jpg`.
> Tip: compress images (e.g. squoosh.app) before upload for faster loading on slow connections.

---

## 1. Create the GitHub repository
1. Sign in at github.com → **New repository** → name it `jeroma-smiles` → **Public** (GitHub Pages is free for public repos) → Create.
2. Do **not** add a README (this project already has one).

## 2. Upload the website
**Easiest:** on the empty repo page choose **uploading an existing file**, drag **the contents** of this folder (all files and folders, *not* the folder wrapper) → **Commit changes**.

**With Git:**
```bash
cd jeroma-smiles
git init && git add . && git commit -m "Jeroma Smiles website"
git branch -M main
git remote add origin https://github.com/YOUR-USER/jeroma-smiles.git
git push -u origin main
```

## 3. Enable GitHub Pages
Repo → **Settings → Pages** → *Build and deployment* → **Source: Deploy from a branch** → Branch **main** / folder **/ (root)** → **Save**.
After ~1 minute the site is live at `https://YOUR-USER.github.io/jeroma-smiles/`.
All paths in the project are relative, so it works in that sub-folder and on a custom domain.

## 4. Create the Supabase project & connect it
1. Go to supabase.com → **New project** (choose a region close to Uganda, e.g. Europe/Frankfurt or similar) → set a strong database password and **save it**.
2. **Project Settings → API**. Copy:
   - **Project URL**
   - **anon / public key**
3. Put them in `js/config.js`:
   ```js
   window.JEROMA_CONFIG = {
     SUPABASE_URL: "https://abcdxyz.supabase.co",
     SUPABASE_ANON_KEY: "eyJhbGciOi…(anon public key)"
   };
   ```
   ⛔ **Never** paste the `service_role` key anywhere in this website. The anon key is designed to be public; Row Level Security (step 5) is what protects your data.
4. **Authentication → URL Configuration**: set **Site URL** to your live site URL, and add `https://YOUR-USER.github.io/jeroma-smiles/principal-login.html` to **Redirect URLs** (needed for password-reset emails).

## 5. Create the tables and Row Level Security
Supabase → **SQL Editor → New query** → paste the whole of `supabase/schema.sql` → **Run**.
This creates:
- `applications`, `enquiries`, `admin_profiles` + indexes
- **RLS policies**:
  - The public can only **submit** (insert) applications/enquiries — they can **never read** anything. Status is forced to `New` / `Unread`.
  - Only a signed-in user listed in `admin_profiles` with `role = 'principal'` can read records and change their **status** (no other column can be edited, and nothing can be deleted).

## 6. Create the principal account
1. Supabase → **Authentication → Users → Add user → Create new user**. Enter the principal's email and a strong password; tick **Auto Confirm User**.
2. Copy the new user's **UID**.
3. In the **SQL Editor** run:
   ```sql
   insert into public.admin_profiles (id, name, email, role)
   values ('PASTE-USER-UID', 'Principal Name', 'principal@example.com', 'principal');
   ```
4. Open `…/principal-login.html` and sign in. A user *without* an `admin_profiles` row is refused, even with a valid password.

## 7. Email notifications (new application → principal's inbox)
Uses **Resend** (free tier) from a Supabase **Edge Function**, so the API key stays secret on the server.
1. Create an account at resend.com, **verify a sending domain** (or use their test sender while testing), and create an **API key**.
2. Install the Supabase CLI and log in: `npm i -g supabase` → `supabase login` → `supabase link --project-ref YOUR-PROJECT-REF`.
3. Set secrets (replace values):
   ```bash
   supabase secrets set RESEND_API_KEY=re_xxx \
     RESEND_FROM="Jeroma Smiles <notifications@yourdomain.com>" \
     NOTIFY_EMAIL=principal@example.com \
     DASHBOARD_URL=https://YOUR-USER.github.io/jeroma-smiles/dashboard.html \
     WEBHOOK_SECRET=make-up-a-long-random-string
   ```
4. Deploy: `supabase functions deploy notify-application --no-verify-jwt`
   (`--no-verify-jwt` is used because the database calls it; it is protected by the `x-webhook-secret` header instead.)
5. Supabase → **Database → Webhooks → Create a new hook**:
   - Table: `applications` · Events: **Insert**
   - Type: **Supabase Edge Functions** → `notify-application`
   - Add HTTP header: `x-webhook-secret` = the same `WEBHOOK_SECRET` value.
6. Submit a test application — the email *"New Admission Application — Jeroma Smiles"* should arrive with a dashboard link.

*Without this step the site still works; the principal simply checks the dashboard.*

## 8. Test the whole flow
1. Open `admissions.html`, submit an application → success message appears.
2. Supabase → **Table Editor → applications**: the row exists with status **New**.
3. Open `principal-login.html`, sign in → the application appears in **Dashboard** and **Admissions**.
4. Try search + filters, open **View**, press **Under Review / Accept / Decline** (Accept/Decline ask for confirmation).
5. Submit the **Contact** form → check **Enquiries**; set Unread → Read → Resolved.
6. Check **Analytics**, **Profile → Change Password**, then **Logout**.
7. While logged out, open `dashboard.html` directly → you are redirected to the login page.
8. Test on a phone (menu, forms, tables become cards).

## 9. Custom domain (optional)
1. Buy a domain. Repo → **Settings → Pages → Custom domain** → enter it (e.g. `www.jeromasmiles.com`) → Save, tick **Enforce HTTPS**.
2. At your registrar add DNS records: `www` → **CNAME** → `YOUR-USER.github.io`; for the bare domain add four **A** records to GitHub Pages' IPs (listed at docs.github.com → "Managing a custom domain for your GitHub Pages site").
3. Update the domain in `canonical`/`og:image` tags (search `REPLACE-WITH-YOUR-DOMAIN.example`), and update the Supabase **Site URL / Redirect URLs** and `DASHBOARD_URL`.

---

## Security notes
- No passwords or secrets are in the code. Sign-in is real **Supabase Auth**; sessions are stored in `sessionStorage` (cleared when the tab closes), never `localStorage`.
- The dashboard is protected by the database (RLS), not just by redirects. Unauthorised visitors see no data even if they bypass the page.
- All text from the public is HTML-escaped before it is displayed in the dashboard.
- Forms have client-side validation, database CHECK constraints, and a hidden honeypot field against basic bots. For heavier spam, add Cloudflare Turnstile later.
- The dashboard loads one library (`@supabase/supabase-js`) from the jsDelivr CDN; the public pages load no third-party scripts. You can pin an exact version or self-host it if preferred.

## Customising
- **Add gallery photos:** put the file in `images/` and add one entry to `PHOTOS` in `js/gallery.js`.
- **Edit page text:** the pages are plain HTML — open any `.html` file and edit.
- **Colours:** `:root` in `css/style.css` (dashboard follows automatically).

---
© 2026 Jeroma Smiles Day Care and Nursery · Website designed & developed by Emtrixz Technology Company
