-- ============================================================
-- Jeroma Smiles — Supabase schema, indexes and Row Level Security
-- Run this whole file once in: Supabase Dashboard → SQL Editor → New query
-- ============================================================

-- ---------- 1. Tables ----------

-- Principal / administrator profiles (one row per allowed admin, linked to Supabase Auth)
create table if not exists public.admin_profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  name        text,
  email       text,
  role        text not null default 'principal' check (role in ('principal')),
  created_at  timestamptz not null default now()
);

-- Admission applications (written by the public website)
create table if not exists public.applications (
  id            uuid primary key default gen_random_uuid(),
  ref_no        bigint generated always as identity unique,   -- shown as JS-0001, JS-0002 …
  created_at    timestamptz not null default now(),
  parent_name   text not null check (char_length(parent_name)  between 2 and 120),
  parent_phone  text not null check (parent_phone ~ '^[+0-9][0-9 ()-]{6,19}$'),
  parent_email  text not null check (char_length(parent_email) <= 160 and parent_email ~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]{2,}$'),
  child_name    text not null check (char_length(child_name)   between 2 and 120),
  child_age     int  not null check (child_age between 0 and 18),
  programme     text not null check (programme in ('Day Care','Nursery','UNEB Primary','ACE','Other')),
  school_type   text not null check (school_type in ('Day','Boarding')),
  message       text check (message is null or char_length(message) <= 2000),
  status        text not null default 'New' check (status in ('New','Under Review','Accepted','Declined'))
);

-- Parent enquiries (written by the public contact form)
create table if not exists public.enquiries (
  id          uuid primary key default gen_random_uuid(),
  created_at  timestamptz not null default now(),
  name        text not null check (char_length(name)    between 2 and 120),
  email       text not null check (char_length(email) <= 160 and email ~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]{2,}$'),
  phone       text check (phone is null or phone = '' or phone ~ '^[+0-9][0-9 ()-]{6,19}$'),
  subject     text not null check (char_length(subject) between 2 and 150),
  message     text not null check (char_length(message) between 1 and 2000),
  status      text not null default 'Unread' check (status in ('Unread','Read','Resolved'))
);

-- ---------- 2. Indexes ----------
create index if not exists applications_created_idx on public.applications (created_at desc);
create index if not exists applications_status_idx  on public.applications (status);
create index if not exists applications_type_idx    on public.applications (school_type, programme);
create index if not exists enquiries_created_idx    on public.enquiries (created_at desc);
create index if not exists enquiries_status_idx     on public.enquiries (status);

-- ---------- 3. Helper: is the signed-in user a principal? ----------
create or replace function public.is_principal()
returns boolean
language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.admin_profiles
    where id = auth.uid() and role = 'principal'
  );
$$;
revoke all on function public.is_principal() from public;
grant execute on function public.is_principal() to anon, authenticated;

-- ---------- 4. Row Level Security ----------
alter table public.admin_profiles enable row level security;
alter table public.applications   enable row level security;
alter table public.enquiries      enable row level security;

-- Start from zero privileges, then grant only what is needed
revoke all on public.admin_profiles from anon, authenticated;
revoke all on public.applications   from anon, authenticated;
revoke all on public.enquiries      from anon, authenticated;

-- admin_profiles: a signed-in user may read ONLY their own profile. Nobody can write from the website.
grant select on public.admin_profiles to authenticated;
drop policy if exists "read own profile" on public.admin_profiles;
create policy "read own profile" on public.admin_profiles
  for select to authenticated using (id = auth.uid());

-- applications: the PUBLIC may only INSERT (status is forced to 'New' because it is not an insertable column)
grant insert (parent_name, parent_phone, parent_email, child_name, child_age, programme, school_type, message)
  on public.applications to anon, authenticated;
drop policy if exists "public can submit applications" on public.applications;
create policy "public can submit applications" on public.applications
  for insert to anon, authenticated with check (status = 'New');

-- applications: only the principal can read them and change the STATUS (nothing else)
grant select on public.applications to authenticated;
grant update (status) on public.applications to authenticated;
drop policy if exists "principal reads applications" on public.applications;
create policy "principal reads applications" on public.applications
  for select to authenticated using (public.is_principal());
drop policy if exists "principal updates application status" on public.applications;
create policy "principal updates application status" on public.applications
  for update to authenticated using (public.is_principal()) with check (public.is_principal());

-- enquiries: same pattern
grant insert (name, email, phone, subject, message) on public.enquiries to anon, authenticated;
drop policy if exists "public can submit enquiries" on public.enquiries;
create policy "public can submit enquiries" on public.enquiries
  for insert to anon, authenticated with check (status = 'Unread');

grant select on public.enquiries to authenticated;
grant update (status) on public.enquiries to authenticated;
drop policy if exists "principal reads enquiries" on public.enquiries;
create policy "principal reads enquiries" on public.enquiries
  for select to authenticated using (public.is_principal());
drop policy if exists "principal updates enquiry status" on public.enquiries;
create policy "principal updates enquiry status" on public.enquiries
  for update to authenticated using (public.is_principal()) with check (public.is_principal());

-- There is deliberately NO delete policy: records cannot be deleted from the website or dashboard.

-- ============================================================
-- 5. CREATE THE PRINCIPAL ACCOUNT (do this AFTER running the above)
-- ============================================================
-- Step A: Supabase Dashboard → Authentication → Users → "Add user" → "Create new user"
--         Enter the principal's email and a strong password (tick "Auto Confirm User").
-- Step B: Copy that user's UID, then run the statement below with the real values:
--
-- insert into public.admin_profiles (id, name, email, role)
-- values ('PASTE-USER-UID-HERE', 'Principal Name', 'principal@example.com', 'principal');
--
-- Only users listed in admin_profiles with role = 'principal' can see any data.
