// Jeroma Smiles — email notification for new admission applications.
// Runs on Supabase Edge Functions (Deno). Called by a Database Webhook on INSERT into
// public.applications. Secrets live in Supabase, never in the website code.
//
// Required secrets (set with `supabase secrets set ...` — see README):
//   RESEND_API_KEY   API key from resend.com
//   RESEND_FROM      e.g. "Jeroma Smiles <notifications@yourdomain.com>" (a domain verified in Resend)
//   NOTIFY_EMAIL     the principal / admin email that receives the alert
//   DASHBOARD_URL    e.g. https://YOUR-USER.github.io/jeroma-smiles/dashboard.html
//   WEBHOOK_SECRET   any long random string; the same value is added as a header on the webhook

const esc = (v: unknown) =>
  String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  // Only our database webhook knows this secret
  if (req.headers.get("x-webhook-secret") !== Deno.env.get("WEBHOOK_SECRET")) {
    return new Response("Unauthorized", { status: 401 });
  }

  let payload: any;
  try { payload = await req.json(); } catch { return new Response("Bad request", { status: 400 }); }
  if (payload?.type !== "INSERT" || payload?.table !== "applications" || !payload?.record) {
    return new Response("Ignored", { status: 200 });
  }

  const a = payload.record;
  const ref = "JS-" + String(a.ref_no ?? "").padStart(4, "0");
  const link = (Deno.env.get("DASHBOARD_URL") ?? "") + "#admissions";

  const row = (k: string, v: unknown) =>
    `<tr><td style="padding:6px 14px 6px 0;color:#666">${k}</td><td style="padding:6px 0"><b>${esc(v)}</b></td></tr>`;

  const html = `
  <div style="font-family:Arial,sans-serif;max-width:560px;color:#111">
    <h2 style="margin:0 0 4px">New Admission Application</h2>
    <p style="margin:0 0 16px;color:#666">Application ${esc(ref)} — Jeroma Smiles</p>
    <table style="border-collapse:collapse;font-size:15px">
      ${row("Parent", a.parent_name)}${row("Child", a.child_name)}${row("Programme", a.programme)}
      ${row("Day / Boarding", a.school_type)}${row("Phone", a.parent_phone)}${row("Email", a.parent_email)}
    </table>
    <p style="margin:24px 0"><a href="${esc(link)}" style="background:#C81E2C;color:#fff;padding:12px 22px;text-decoration:none;font-weight:bold">Open in dashboard</a></p>
    <p style="color:#888;font-size:12px">Sign in to the principal dashboard to read the full message and respond.</p>
  </div>`;

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Authorization": `Bearer ${Deno.env.get("RESEND_API_KEY")}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: Deno.env.get("RESEND_FROM"),
      to: [Deno.env.get("NOTIFY_EMAIL")],
      subject: "New Admission Application — Jeroma Smiles",
      html,
    }),
  });

  if (!res.ok) return new Response("Email provider error", { status: 502 });
  return new Response("Sent", { status: 200 });
});
